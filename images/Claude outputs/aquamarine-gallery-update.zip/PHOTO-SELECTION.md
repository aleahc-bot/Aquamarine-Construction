# Aquamarine gallery: photo selection notes

30 unique photos were received (duplicate uploads removed by file hash).

## Main gallery (17 new + 3 existing site photos)
| Filter | Photos |
|---|---|
| Docks | Riverfront dock & ladder, curved grated walkway, grated walkway, herringbone deck inlay |
| Boat Lifts | Dolphin lift slip, Dolphin lift cradle, covered lift (triple outboards), 3 platform lifts, existing `boat-lift.jpg` |
| Tiki Huts | Round dining hut, egg-chair hut, built-in octagon table, ceiling fan interior, fresh thatch, existing `tiki-boat-lift.jpg` |
| Seawalls | Seawall cap & composite walkway, step-down dock at seawall (cropped) |
| Kayak | Existing `kayak-station.jpg` (no new kayak photos were sent) |

## Work in Progress strip
Materials staged + crane barge, decking going down + crane barge, dock framing (cropped), existing `dock.jpg` (crew framing).

## Before & After ("In progress" → "Completed")
1. Materials staged on lawn → finished riverfront grated dock
2. Composite framing at seawall → finished step-down dock

**Please confirm both pairs are the same job.** They were matched by location clues (same river, palms, lumber and seawall cap). No true "old dock before demolition" photos were in the batch; if you have any, they'd make stronger pairs.

## Cropped
- Dock framing and step-down dock: cropped to remove the "Highland Excavating" silt-fence banner (another company's name).

## Set aside (not on the site)
| File | Reason |
|---|---|
| dolphin-box-OLD-PHONE-243-4011 | Lift box shows old number 243-4011, not the current (239) 946-5818 |
| tiki-ceiling-client-signage | Client's personal signs ("The Girls Are Drinking Again", etc.) |
| piling-deck-closeup-inspection | Inspection-style close-up |
| pile-cap-bracket-inspection | Hardware/inspection detail |
| lift-motor-internals | Mechanical detail, cluttered background |
| piling-obstructs-view | Piling blocks the shot |
| dolphin-slip-wide-angle-duplicate | Wide-angle distortion; straight-on version used |
| herringbone-duplicate | Second angle of same inlay |
| river-dock-duplicate-angle | Near-duplicate of the ladder shot |

Note: several Dolphin lift boxes in the *used* photos also show 243-4011 in small print. It's barely legible at gallery size, but worth knowing.

## Image sizes
Full size: 1600px long edge (JPEG q80). Thumbnails: 800px (q74). Total ~8.8 MB full / 1.8 MB thumbs. Pages load thumbs; the full size loads only when a photo is opened.
